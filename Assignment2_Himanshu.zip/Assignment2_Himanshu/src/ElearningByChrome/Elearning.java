package ElearningByChrome;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;

public class Elearning {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws InterruptedException {
		
		String driverLocation = "D:/selenium_drivers/new/chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", driverLocation);
		ChromeDriverService.Builder builder=new ChromeDriverService.Builder();
		ChromeDriverService srvc=builder.usingDriverExecutable(new File(driverLocation)).usingAnyFreePort().build();
		try {
			srvc.start();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebDriver driver= new ChromeDriver(srvc);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("http://elearning.infogain.com:8383/moodle/");
		System.out.println("<------------successfully setup the browser-------------->");
		
		WebElement webElement=driver.findElement(By.partialLinkText("Courses"));
		webElement.click();
		
		webElement=driver.findElement(By.partialLinkText("Log in"));
		webElement.click();
		driver.findElement(By.name("username")).sendKeys("himanshu.dixit@infogain.com");
		
		driver.findElement(By.name("password")).sendKeys("Krishna@210995");
		
		driver.findElement(By.id("loginbtn")).click();
		System.out.println("-------------successfully logged in---------------");

		driver.findElement(By.partialLinkText("Infogain Certified Automation Testing Using Seleni...")).click();
		System.out.println("<-------------clicking on to the course----------->");

		driver.findElement(By.partialLinkText("Automation Testing Using Selenium Web Driver Part 5 _Video")).click();
		
    	
		driver.findElement(By.className("vjs-big-play-button")).click();
		Thread.sleep(3000);
		System.out.println("--------------successfullyy played a video---------");

		driver.findElement(By.partialLinkText("Log out")).click();
		System.out.println("<-----------------Successfully Logout---------------->");
		srvc.stop();
		driver.quit();
		
		
	}//end of main method
}//end of Elearning class
